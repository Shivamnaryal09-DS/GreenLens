"""
utils/charts.py
───────────────
Chart builder helpers using Plotly for rich interactive visuals.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Brand palette
GREEN_DARK   = "#1a3320"
GREEN_MID    = "#3a7d44"
GREEN_LIGHT  = "#a5d6a7"
RISK_PALETTE = {
    "critical": "#c62828",
    "high":     "#e65100",
    "medium":   "#f57f17",
    "low":      "#2e7d32",
}

PLOTLY_LAYOUT = dict(
    font_family="IBM Plex Sans",
    plot_bgcolor="white",
    paper_bgcolor="white",
    margin=dict(l=16, r=16, t=36, b=16),
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1,
        font_size=11,
    ),
)


# ── Risk Bar Chart ────────────────────────────────────────────────

def ward_risk_bar(ward_df: pd.DataFrame, height: int = 300) -> go.Figure:
    """Horizontal bar chart of ward risk scores, colour-coded by tier."""
    from models.risk_model import classify_risk

    df = ward_df.sort_values("Risk Score", ascending=True).tail(30)
    colors = [RISK_PALETTE[classify_risk(r)] for r in df["Risk Score"]]

    fig = go.Figure(go.Bar(
        x=df["Risk Score"],
        y=df["Ward"],
        orientation="h",
        marker_color=colors,
        text=[f"{r:.3f}" for r in df["Risk Score"]],
        textposition="outside",
        textfont_size=10,
    ))
    fig.update_layout(
        **PLOTLY_LAYOUT,
        height=height,
        xaxis=dict(title="Risk Score", range=[0, 1.1], gridcolor="#f0f0f0"),
        yaxis=dict(title=""),
        showlegend=False,
    )
    return fig


# ── NDVI Line Chart ───────────────────────────────────────────────

def ndvi_line_chart(ndvi_df: pd.DataFrame, height: int = 280) -> go.Figure:
    """Multi-scenario NDVI trajectory line chart."""
    fig = go.Figure()
    colors = [GREEN_MID, "#c62828", "#0277bd", "#6a1b9a", "#e65100"]

    for i, col in enumerate(ndvi_df.columns):
        is_baseline = "baseline" in col.lower() or "no policy" in col.lower()
        fig.add_trace(go.Scatter(
            x=ndvi_df.index,
            y=ndvi_df[col],
            name=col,
            mode="lines+markers",
            line=dict(
                color=colors[i % len(colors)],
                width=2.5 if not is_baseline else 1.5,
                dash="dot" if is_baseline else "solid",
            ),
            marker=dict(size=6),
        ))

    fig.update_layout(
        **PLOTLY_LAYOUT,
        height=height,
        xaxis=dict(title="Year", gridcolor="#f0f0f0"),
        yaxis=dict(title="Mean NDVI", gridcolor="#f0f0f0"),
    )
    return fig


# ── Green Cover Area Chart ────────────────────────────────────────

def green_cover_area(gc_df: pd.DataFrame, height: int = 220) -> go.Figure:
    """Stacked area chart of green cover % per scenario."""
    fig = go.Figure()
    colors = [GREEN_MID, "#0277bd", "#6a1b9a", "#e65100", "#c62828"]
    opacities = [0.35, 0.25, 0.20, 0.18, 0.15]

    for i, col in enumerate(gc_df.columns):
        fig.add_trace(go.Scatter(
            x=gc_df.index,
            y=gc_df[col],
            name=col,
            fill="tozeroy",
            mode="lines",
            line=dict(color=colors[i % len(colors)], width=2),
            fillcolor=f"rgba({_hex_to_rgb(colors[i % len(colors)])},{opacities[i % len(opacities)]})",
        ))

    fig.update_layout(
        **PLOTLY_LAYOUT,
        height=height,
        xaxis=dict(title="Year", gridcolor="#f0f0f0"),
        yaxis=dict(title="Green Cover %", tickformat=".1%", gridcolor="#f0f0f0"),
    )
    return fig


# ── High-Risk Wards Line Chart ────────────────────────────────────

def high_risk_wards_line(hrw_df: pd.DataFrame, height: int = 240) -> go.Figure:
    """Line chart of high-risk ward count over time."""
    fig = go.Figure()
    colors = [GREEN_MID, "#c62828", "#0277bd", "#6a1b9a", "#e65100"]

    for i, col in enumerate(hrw_df.columns):
        fig.add_trace(go.Scatter(
            x=hrw_df.index,
            y=hrw_df[col],
            name=col,
            mode="lines+markers",
            line=dict(color=colors[i % len(colors)], width=2.2),
            marker=dict(size=7, symbol="circle"),
        ))

    fig.update_layout(
        **PLOTLY_LAYOUT,
        height=height,
        xaxis=dict(title="Year", gridcolor="#f0f0f0"),
        yaxis=dict(title="High-Risk Wards", gridcolor="#f0f0f0"),
    )
    return fig


# ── NDVI History Line ─────────────────────────────────────────────

def ndvi_history_line(history_df: pd.DataFrame, height: int = 260) -> go.Figure:
    """Historical NDVI trend with moving average."""
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=history_df["date"],
        y=history_df["mean_ndvi"],
        name="Monthly NDVI",
        mode="lines+markers",
        line=dict(color=GREEN_MID, width=2),
        marker=dict(size=5),
    ))

    # 3-month rolling average
    rolling = history_df["mean_ndvi"].rolling(3).mean()
    fig.add_trace(go.Scatter(
        x=history_df["date"],
        y=rolling,
        name="3-Month MA",
        mode="lines",
        line=dict(color="#c62828", width=2.5, dash="dash"),
    ))

    fig.update_layout(
        **PLOTLY_LAYOUT,
        height=height,
        xaxis=dict(title="", gridcolor="#f0f0f0"),
        yaxis=dict(title="NDVI", gridcolor="#f0f0f0"),
    )
    return fig


# ── Risk Tier Donut ───────────────────────────────────────────────

def risk_donut(metrics: Dict, height: int = 280) -> go.Figure:
    critical = metrics["critical_wards"]
    high     = metrics["high_risk_wards"] - critical
    medium   = metrics["medium_risk_wards"]
    low      = metrics["low_risk_wards"]

    fig = go.Figure(go.Pie(
        labels=["Critical", "High", "Medium", "Low"],
        values=[critical, high, medium, low],
        hole=0.55,
        marker_colors=["#c62828", "#e65100", "#f57f17", "#2e7d32"],
        textinfo="label+percent",
        textfont_size=11,
    ))
    fig.update_layout(
        **PLOTLY_LAYOUT,
        height=height,
        showlegend=False,
        annotations=[dict(
            text=f"<b>{metrics['total_wards']}</b><br>wards",
            x=0.5, y=0.5,
            font_size=14,
            showarrow=False,
        )],
    )
    return fig


# ── Tree Count Bar ────────────────────────────────────────────────

def tree_count_bar(results: Dict, height: int = 220) -> go.Figure:
    names  = []
    counts = []
    for name, data in results.items():
        names.append(name[:30])
        counts.append(data["metrics"][-1]["total_tree_count"])

    fig = go.Figure(go.Bar(
        x=names,
        y=counts,
        marker_color=GREEN_MID,
        text=[f"{c:,}" for c in counts],
        textposition="outside",
        textfont_size=10,
    ))
    fig.update_layout(
        **PLOTLY_LAYOUT,
        height=height,
        xaxis=dict(title=""),
        yaxis=dict(title="Total Trees", gridcolor="#f0f0f0"),
        showlegend=False,
    )
    return fig


# ── Word Frequency Bar ────────────────────────────────────────────

def word_freq_bar(word_df: pd.DataFrame, height: int = 200) -> go.Figure:
    df = word_df.head(15).sort_values("Count", ascending=True)
    fig = go.Figure(go.Bar(
        x=df["Count"],
        y=df["Word"],
        orientation="h",
        marker_color=GREEN_LIGHT,
        marker_line_color=GREEN_MID,
        marker_line_width=1,
    ))
    fig.update_layout(
        **PLOTLY_LAYOUT,
        height=height,
        xaxis=dict(title="Frequency", gridcolor="#f0f0f0"),
        yaxis=dict(title=""),
        showlegend=False,
    )
    return fig


# ── Helper ────────────────────────────────────────────────────────

def _hex_to_rgb(hex_color: str) -> str:
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"{r},{g},{b}"
