"""
utils/styling.py
────────────────
CSS injection and reusable HTML component helpers for Streamlit.
"""

import streamlit as st


GLOBAL_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;800;900&family=IBM+Plex+Sans:ital,wght@0,300;0,400;0,500;0,600;1,300&family=IBM+Plex+Mono:wght@400;500&display=swap');

/* ── Reset & Base ── */
html, body, [class*="css"] {
    font-family: 'IBM Plex Sans', sans-serif;
}
h1, h2, h3, h4 {
    font-family: 'Playfair Display', serif;
}
.stApp {
    background: #f4f7f2;
}

/* ── Sidebar ── */
div[data-testid="stSidebar"] {
    background: linear-gradient(175deg, #0c1f0f 0%, #1a3320 55%, #243d29 100%);
    border-right: 1px solid rgba(58,125,68,0.4);
}
div[data-testid="stSidebar"] * {
    color: #c8e6c9 !important;
}
div[data-testid="stSidebar"] hr {
    border-color: rgba(58,125,68,0.4) !important;
}
div[data-testid="stSidebar"] .stRadio > label {
    font-size: 0.85rem;
    padding: 0.4rem 0.6rem;
    border-radius: 6px;
    transition: background 0.15s;
}
div[data-testid="stSidebar"] .stRadio > label:hover {
    background: rgba(255,255,255,0.06);
}

/* ── Metric Cards ── */
.metric-card {
    background: #ffffff;
    border-radius: 14px;
    padding: 1.1rem 1.3rem 0.9rem;
    border-left: 4px solid #3a7d44;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06), 0 4px 14px rgba(0,0,0,0.04);
    transition: transform 0.15s, box-shadow 0.15s;
    height: 100%;
}
.metric-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(0,0,0,0.09);
}
.mc-label {
    font-size: 0.65rem;
    font-weight: 600;
    color: #9e9e9e;
    text-transform: uppercase;
    letter-spacing: 0.09em;
    margin-bottom: 0.25rem;
}
.mc-value {
    font-family: 'Playfair Display', serif;
    font-size: 2rem;
    font-weight: 700;
    line-height: 1;
    margin-bottom: 0.2rem;
}
.mc-sub {
    font-size: 0.70rem;
    color: #bdbdbd;
    font-family: 'IBM Plex Mono', monospace;
}

/* ── Section Headers ── */
.section-header {
    font-family: 'Playfair Display', serif;
    font-size: 1.25rem;
    font-weight: 700;
    color: #1a2e1d;
    border-bottom: 2px solid #a5d6a7;
    padding-bottom: 0.25rem;
    margin-bottom: 0.9rem;
    margin-top: 0.3rem;
}

/* ── Page Title Block ── */
.page-title {
    font-family: 'Playfair Display', serif;
    font-size: 2rem;
    font-weight: 800;
    color: #1a2e1d;
    line-height: 1.1;
    margin-bottom: 0.1rem;
}
.page-caption {
    font-size: 0.79rem;
    color: #9e9e9e;
    font-family: 'IBM Plex Mono', monospace;
    letter-spacing: 0.02em;
    margin-bottom: 1.3rem;
}

/* ── Info / Alert Boxes ── */
.info-box {
    background: #e8f5e9;
    border-radius: 8px;
    padding: 0.75rem 1rem;
    font-size: 0.82rem;
    color: #1b5e20;
    border-left: 3px solid #43a047;
    margin-bottom: 0.75rem;
}
.warn-box {
    background: #fff8e1;
    border-radius: 8px;
    padding: 0.75rem 1rem;
    font-size: 0.82rem;
    color: #e65100;
    border-left: 3px solid #ffa000;
    margin-bottom: 0.75rem;
}

/* ── Badges ── */
.badge {
    border-radius: 999px;
    padding: 2px 11px;
    font-size: 0.70rem;
    font-weight: 600;
    display: inline-block;
    margin: 2px;
}
.badge-critical { background:#fde8e8; color:#c62828; }
.badge-high     { background:#fff3e0; color:#e65100; }
.badge-medium   { background:#fffde7; color:#f57f17; }
.badge-low      { background:#e8f5e9; color:#2e7d32; }
.badge-info     { background:#e3f2fd; color:#1565c0; }

/* ── Upload Placeholder ── */
.upload-placeholder {
    background: #ffffff;
    border: 2px dashed #a5d6a7;
    border-radius: 16px;
    padding: 3.5rem 2rem;
    text-align: center;
    color: #9e9e9e;
}
.upload-placeholder h3 {
    color: #3a7d44;
    font-family: 'Playfair Display', serif;
    margin-bottom: 0.5rem;
}

/* ── Extraction Result Rows ── */
.extract-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.5rem 0;
    border-bottom: 1px solid #f5f5f5;
    font-size: 0.83rem;
}
.extract-row:last-child { border-bottom: none; }
.ek { color: #616161; font-weight: 500; }
.ev {
    font-family: 'IBM Plex Mono', monospace;
    color: #1b5e20;
    background: #f1f8e9;
    padding: 1px 8px;
    border-radius: 4px;
    font-size: 0.76rem;
}

/* ── Sidebar Brand & Meta ── */
.sidebar-brand {
    font-family: 'Playfair Display', serif;
    font-size: 1.25rem;
    font-weight: 800;
    color: #a5d6a7 !important;
    letter-spacing: -0.01em;
    line-height: 1.3;
}
.sidebar-meta {
    font-size: 0.72rem;
    color: #81c784 !important;
    line-height: 1.9;
    font-family: 'IBM Plex Mono', monospace;
}

/* ── Analytics card ── */
.analytics-card {
    background: white;
    border-radius: 12px;
    padding: 1.2rem 1.4rem;
    box-shadow: 0 1px 4px rgba(0,0,0,0.06);
    margin-bottom: 1rem;
}
</style>
"""


def inject_css():
    """Inject global CSS into the Streamlit page."""
    st.markdown(GLOBAL_CSS, unsafe_allow_html=True)


# ── Reusable HTML Components ──────────────────────────────────────

def metric_card(label: str, value: str, sub: str, color: str) -> str:
    return (
        f'<div class="metric-card" style="border-left-color:{color}">'
        f'<div class="mc-label">{label}</div>'
        f'<div class="mc-value" style="color:{color}">{value}</div>'
        f'<div class="mc-sub">{sub}</div>'
        f"</div>"
    )


def section_header(text: str, margin_top: str = "0.3rem") -> str:
    return (
        f'<div class="section-header" style="margin-top:{margin_top}">'
        f"{text}"
        f"</div>"
    )


def page_header(title: str, caption: str):
    st.markdown(f'<div class="page-title">{title}</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="page-caption">{caption}</div>', unsafe_allow_html=True)


def info_box(text: str):
    st.markdown(f'<div class="info-box">{text}</div>', unsafe_allow_html=True)


def warn_box(text: str):
    st.markdown(f'<div class="warn-box">{text}</div>', unsafe_allow_html=True)


def badge(text: str, level: str = "info") -> str:
    return f'<span class="badge badge-{level}">{text}</span>'


def extract_row(label: str, value) -> str:
    return (
        f'<div class="extract-row">'
        f'<span class="ek">{label}</span>'
        f'<span class="ev">{value}</span>'
        f"</div>"
    )
