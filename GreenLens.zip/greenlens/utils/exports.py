"""
utils/exports.py
────────────────
JSON and CSV export helpers for download buttons.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List

import pandas as pd


def to_json(data: Any, indent: int = 2) -> str:
    """Serialize data to JSON string with safe defaults."""
    def _default(obj):
        if hasattr(obj, "tolist"):  return obj.tolist()
        if hasattr(obj, "item"):    return obj.item()
        return str(obj)
    return json.dumps(data, indent=indent, default=_default)


def ward_df_to_csv(ward_risks: Dict[str, float]) -> str:
    """Convert ward risk dict to CSV string."""
    from models.risk_model import classify_risk
    rows = [
        {"Ward": w, "Risk Score": r, "Risk Level": classify_risk(r).title()}
        for w, r in ward_risks.items()
    ]
    return pd.DataFrame(rows).sort_values("Risk Score", ascending=False).to_csv(index=False)


def simulation_to_csv(results: Dict) -> str:
    """Flatten simulation results into a CSV string."""
    rows = [
        {"scenario": name, **row}
        for name, sdata in results.items()
        for row in sdata["metrics"]
    ]
    return pd.DataFrame(rows).to_csv(index=False)


def simulation_summary_to_csv(results: Dict) -> str:
    """One row per scenario summary CSV."""
    rows = []
    for name, sdata in results.items():
        final = sdata["metrics"][-1]
        rows.append({
            "Scenario":         name,
            "Final NDVI":       final["mean_ndvi"],
            "Delta vs Baseline":sdata["delta_ndvi_vs_baseline"],
            "Pct Improvement":  sdata["pct_improvement"],
            "High Risk Wards":  final["high_risk_wards"],
            "Total Trees":      final["total_tree_count"],
            "CO2 Offset (t)":   final.get("co2_offset_tons", ""),
            "Temp Reduction (C)":final.get("temp_reduction_c", ""),
        })
    return pd.DataFrame(rows).to_csv(index=False)
