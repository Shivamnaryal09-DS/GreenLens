"""
config/settings.py
──────────────────
App-wide constants, thresholds, and default configuration.
Edit this file to change city, ward count, risk levels, etc.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple


# ── City ──────────────────────────────────────────────────────────
CITY_NAME        = "Bengaluru, India"
CITY_LAT         = 12.9716
CITY_LON         = 77.5946
ANALYSIS_DATE    = "2024-01"
DEMO_SEED        = 99
N_WARDS          = 30

# ── City Registry ─────────────────────────────────────────────────
CITY_REGISTRY: Dict[str, Dict] = {
    "Bengaluru": {
        "label":   "Bengaluru, India",
        "lat":     12.9716,
        "lon":     77.5946,
        "n_wards": 30,
        "seed":    99,
    },
    "Delhi": {
        "label":   "Delhi, India",
        "lat":     28.6139,
        "lon":     77.2090,
        "n_wards": 35,
        "seed":    42,
    },
    "Pune": {
        "label":   "Pune, India",
        "lat":     18.5204,
        "lon":     73.8567,
        "n_wards": 25,
        "seed":    17,
    },
    "Mandi": {
        "label":   "Mandi, Himachal Pradesh",
        "lat":     31.7080,
        "lon":     76.9320,
        "n_wards": 18,
        "seed":    55,
    },
    "Chamba": {
        "label":   "Chamba, Himachal Pradesh",
        "lat":     32.5534,
        "lon":     76.1258,
        "n_wards": 15,
        "seed":    61,
    },
    "Chennai": {
        "label":   "Chennai, India",
        "lat":     13.0827,
        "lon":     80.2707,
        "n_wards": 28,
        "seed":    73,
    },
    "Mumbai": {
        "label":   "Mumbai, India",
        "lat":     19.0760,
        "lon":     72.8777,
        "n_wards": 32,
        "seed":    88,
    },
}

DEFAULT_CITY = "Bengaluru"

# ── Risk Thresholds ──────────────────────────────────────────────
RISK_THRESHOLDS: Dict[str, float] = {
    "critical": 0.75,
    "high":     0.50,
    "medium":   0.25,
    "low":      0.00,
}

RISK_COLORS: Dict[str, str] = {
    "critical": "#c62828",
    "high":     "#e65100",
    "medium":   "#f57f17",
    "low":      "#2e7d32",
}

RISK_BG_COLORS: Dict[str, str] = {
    "critical": "#fde8e8",
    "high":     "#fff3e0",
    "medium":   "#fffde7",
    "low":      "#e8f5e9",
}

RISK_RGBA: Dict[str, List[int]] = {
    "critical": [198, 40, 40,  210],
    "high":     [230, 81,  0,  185],
    "medium":   [245, 127, 23, 160],
    "low":      [46,  125, 50, 140],
}

# ── Simulation ────────────────────────────────────────────────────
SIM_BASE_YEAR       = 2024
SIM_DEFAULT_HORIZON = 5
SIM_MAX_HORIZON     = 10
SIM_BASELINE_NDVI   = 0.31
SIM_SEED            = 7

CLIMATE_SCENARIOS = ["moderate", "optimistic", "pessimistic"]

INTERVENTION_REGISTRY: Dict[str, Dict] = {
    "tree_planting": {
        "label":       "Tree Planting",
        "unit":        "trees/year",
        "description": "Plant native tree species across wards",
        "color":       "#2e7d32",
        "default_mag": 10_000.0,
    },
    "green_roof": {
        "label":       "Green Roof Installations",
        "unit":        "m² installed",
        "description": "Install vegetated roof systems on buildings",
        "color":       "#0277bd",
        "default_mag": 5_000.0,
    },
    "park_creation": {
        "label":       "Park / Green Space Creation",
        "unit":        "hectares",
        "description": "Convert vacant land to public parks",
        "color":       "#6a1b9a",
        "default_mag": 50.0,
    },
    "urban_farming": {
        "label":       "Urban Farming Zones",
        "unit":        "plots",
        "description": "Establish community agriculture zones",
        "color":       "#e65100",
        "default_mag": 200.0,
    },
    "tree_preservation": {
        "label":       "Tree Preservation Orders",
        "unit":        "trees protected",
        "description": "Legal protection for existing mature trees",
        "color":       "#00838f",
        "default_mag": 3_000.0,
    },
    "corridor_planting": {
        "label":       "Green Corridor Planting",
        "unit":        "km of road",
        "description": "Plant trees along roads and transit corridors",
        "color":       "#558b2f",
        "default_mag": 100.0,
    },
}

# ── Upload ───────────────────────────────────────────────────────
MAX_UPLOAD_MB   = 32
PDF_MAX_PAGES   = 10
SUPPORTED_EXTS  = ["pdf", "txt", "csv", "xlsx"]

# ── App ──────────────────────────────────────────────────────────
APP_VERSION = "1.0.0"
APP_TITLE   = "GreenLens"
APP_ICON    = "🌿"
