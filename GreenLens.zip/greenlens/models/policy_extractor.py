"""
models/policy_extractor.py
──────────────────────────
NLP-based policy document signal extractor.
Primary: HuggingFace BERT (if installed)
Fallback: Heuristic regex-based extraction
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional


# ── Heuristic Extractor (always available) ────────────────────────

class HeuristicExtractor:
    """
    Rule-based signal extractor using regex patterns.
    Used when BERT/transformers is not installed.
    """

    KEYWORDS: Dict[str, List[str]] = {
        "tree_planting":    ["tree", "planting", "saplings", "afforestation", "reforestation"],
        "park_creation":    ["park", "garden", "playground", "public space", "green space"],
        "green_roof":       ["green roof", "rooftop garden", "living roof", "vegetated roof"],
        "urban_farming":    ["urban farm", "community garden", "kitchen garden", "agriculture zone"],
        "tree_preservation":["preserve", "protection order", "heritage tree", "tree felling ban"],
        "corridor_planting":["corridor", "avenue", "boulevard", "road side planting"],
    }

    POSITIVE_WORDS = [
        "plant", "create", "green", "increase", "restore", "improve",
        "expand", "develop", "establish", "launch", "initiative", "project",
    ]
    NEGATIVE_WORDS = ["remove", "cut", "fell", "demolish", "reduce", "clear"]

    def extract(self, text: str) -> Dict[str, Any]:
        text_lower = text.lower()

        # Detected event types
        detected = []
        for event, kws in self.KEYWORDS.items():
            if any(kw in text_lower for kw in kws):
                detected.append(event)

        # Primary event
        primary = detected[0] if detected else "unknown"

        # Impact direction
        pos = sum(1 for w in self.POSITIVE_WORDS if w in text_lower)
        neg = sum(1 for w in self.NEGATIVE_WORDS if w in text_lower)
        direction = "positive" if pos > neg else ("negative" if neg > pos else "neutral")

        # Numeric extraction
        tree_nums  = re.findall(r"\b(\d[\d,]*)\s*trees?\b", text, re.I)
        area_sqm   = re.findall(r"\b(\d[\d,]*)\s*(?:sqm|sq\.m)\b", text, re.I)
        area_ha    = re.findall(r"\b(\d[\d,]*)\s*hectares?\b", text, re.I)
        ward_refs  = re.findall(r"\bward[- ]?(\w+)\b", text, re.I)
        year_refs  = re.findall(r"\b(20\d{2})\b", text)
        budget     = re.findall(r"(?:₹|Rs\.?|INR)\s*([\d,]+(?:\s*(?:crore|lakh|million))?)", text, re.I)
        targets    = re.findall(r"\b(\d[\d,]*)\s*(?:trees?|saplings?|plants?)\s*(?:to be|will be|shall be)?\s*planted", text, re.I)

        return {
            "primary_event":     primary,
            "impact_direction":  direction,
            "detected_events":   detected or ["not detected"],
            "trees_mentioned":   int(tree_nums[0].replace(",", "")) if tree_nums else 0,
            "planting_target":   int(targets[0].replace(",", "")) if targets else 0,
            "area_sqm":          float(area_sqm[0].replace(",", "")) if area_sqm else 0.0,
            "area_hectares":     float(area_ha[0].replace(",", "")) if area_ha else 0.0,
            "ward":              ward_refs[0] if ward_refs else "not detected",
            "year_references":   list(set(year_refs))[:5],
            "budget_mention":    budget[0] if budget else "not detected",
            "_model":            "heuristic",
        }


# ── BERT Extractor (optional, requires transformers) ──────────────

class BERTExtractor:
    """
    Transformer-based policy extractor.
    Requires: pip install transformers torch
    """

    def __init__(self, model_name: str = "bert-base-uncased"):
        from transformers import pipeline
        self.classifier = pipeline(
            "zero-shot-classification",
            model=model_name,
            device=-1,  # CPU
        )
        self.labels = [
            "tree planting initiative",
            "park and green space creation",
            "green roof installation",
            "urban farming and community gardens",
            "tree preservation order",
            "green corridor development",
            "environmental policy",
            "urban development",
        ]

    def extract(self, text: str) -> Dict[str, Any]:
        snippet = text[:512]
        result  = self.classifier(snippet, self.labels, multi_label=True)

        top_label = result["labels"][0].lower()
        event_map = {
            "tree planting":     "tree_planting",
            "park":              "park_creation",
            "green roof":        "green_roof",
            "urban farming":     "urban_farming",
            "preservation":      "tree_preservation",
            "corridor":          "corridor_planting",
        }
        primary = next((v for k, v in event_map.items() if k in top_label), "unknown")

        # Still use heuristics for numbers
        heuristic = HeuristicExtractor().extract(text)
        heuristic.update({
            "primary_event":    primary,
            "detected_events":  [primary] if primary != "unknown" else ["not detected"],
            "_model":           "BERT zero-shot",
            "_bert_scores":     dict(zip(result["labels"][:5], [round(s, 3) for s in result["scores"][:5]])),
        })
        return heuristic


# ── Factory ───────────────────────────────────────────────────────

def get_extractor() -> HeuristicExtractor | BERTExtractor:
    """Return the best available extractor."""
    try:
        extractor = BERTExtractor()
        return extractor
    except Exception:
        return HeuristicExtractor()
