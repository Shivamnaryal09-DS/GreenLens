"""
models/risk_model.py
────────────────────
Ward risk scoring engine.
Classifies wards by risk level and provides helper methods.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

from config.settings import (
    RISK_THRESHOLDS, RISK_COLORS, RISK_BG_COLORS, RISK_RGBA,
)


def classify_risk(score: float) -> str:
    """Return risk tier label for a given score."""
    if score > RISK_THRESHOLDS["critical"]:  return "critical"
    elif score > RISK_THRESHOLDS["high"]:    return "high"
    elif score > RISK_THRESHOLDS["medium"]:  return "medium"
    else:                                     return "low"


def risk_color(score: float) -> str:
    """Return hex color for risk score."""
    return RISK_COLORS[classify_risk(score)]


def risk_bg_color(score: float) -> str:
    """Return background hex color for risk score."""
    return RISK_BG_COLORS[classify_risk(score)]


def risk_rgba(score: float) -> List[int]:
    """Return RGBA list [r, g, b, a] for map rendering."""
    return RISK_RGBA[classify_risk(score)]


def cell_style(val: float) -> str:
    """Pandas Styler applymap function."""
    return (
        f"background-color:{risk_bg_color(val)};"
        f"color:{risk_color(val)};"
        f"font-weight:600"
    )


def compute_metrics(ward_risks: Dict[str, float]) -> Dict:
    """Compute aggregate city-level metrics from ward risk scores."""
    import numpy as np
    risks = list(ward_risks.values())
    arr   = __import__("numpy").array(risks)

    return {
        "overall_health_score": round(float(100 * (1 - arr.mean())), 1),
        "critical_wards":       int((arr > RISK_THRESHOLDS["critical"]).sum()),
        "high_risk_wards":      int((arr > RISK_THRESHOLDS["high"]).sum()),
        "medium_risk_wards":    int(((arr > RISK_THRESHOLDS["medium"]) & (arr <= RISK_THRESHOLDS["high"])).sum()),
        "low_risk_wards":       int((arr <= RISK_THRESHOLDS["medium"]).sum()),
        "total_wards":          len(risks),
        "pct_wards_at_risk":    round(float((arr > RISK_THRESHOLDS["high"]).mean() * 100), 1),
        "worst_ward":           list(ward_risks.keys())[int(arr.argmax())],
        "best_ward":            list(ward_risks.keys())[int(arr.argmin())],
        "mean_risk":            round(float(arr.mean()), 3),
        "std_risk":             round(float(arr.std()), 3),
    }


def rank_wards(ward_risks: Dict[str, float], ascending: bool = False) -> List[Tuple[str, float, str]]:
    """Return list of (ward, score, level) sorted by score."""
    ranked = sorted(ward_risks.items(), key=lambda x: x[1], reverse=not ascending)
    return [(w, r, classify_risk(r)) for w, r in ranked]
