"""
tests/test_simulation.py
────────────────────────
Unit tests for the counterfactual simulation engine.
Run with: pytest tests/test_simulation.py -v
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from data.generators import run_simulation, generate_city_analysis, generate_ndvi_history


class TestRunSimulation:
    def setup_method(self):
        self.scenarios = [
            {"name": "Baseline (No Policy)", "interventions": {}},
            {"name": "Tree Planting Scenario", "interventions": {
                "2024": [{"type": "tree_planting", "magnitude": 10000}],
                "2025": [{"type": "tree_planting", "magnitude": 10000}],
            }},
        ]

    def test_returns_all_scenarios(self):
        results = run_simulation(self.scenarios, horizon=3)
        assert "Baseline (No Policy)" in results
        assert "Tree Planting Scenario" in results

    def test_horizon_length(self):
        results = run_simulation(self.scenarios, horizon=5)
        baseline_metrics = results["Baseline (No Policy)"]["metrics"]
        assert len(baseline_metrics) == 5

    def test_years_are_sequential(self):
        results = run_simulation(self.scenarios, horizon=4)
        years = [row["year"] for row in results["Baseline (No Policy)"]["metrics"]]
        assert years == [2024, 2025, 2026, 2027]

    def test_ndvi_is_positive(self):
        results = run_simulation(self.scenarios, horizon=5)
        for name, data in results.items():
            for row in data["metrics"]:
                assert row["mean_ndvi"] > 0

    def test_baseline_ndvi_declines(self):
        results = run_simulation(self.scenarios, horizon=5, climate="moderate")
        baseline = results["Baseline (No Policy)"]["metrics"]
        # Baseline should trend downward over time
        assert baseline[-1]["mean_ndvi"] < baseline[0]["mean_ndvi"]

    def test_delta_ndvi_field_exists(self):
        results = run_simulation(self.scenarios, horizon=3)
        for name, data in results.items():
            assert "delta_ndvi_vs_baseline" in data

    def test_baseline_delta_is_zero(self):
        results = run_simulation(self.scenarios, horizon=3)
        # Baseline delta vs itself = 0
        assert results["Baseline (No Policy)"]["delta_ndvi_vs_baseline"] == 0.0

    def test_policy_has_positive_delta(self):
        results = run_simulation(self.scenarios, horizon=5, climate="optimistic")
        policy_delta = results["Tree Planting Scenario"]["delta_ndvi_vs_baseline"]
        # Under optimistic climate, policy should outperform baseline
        assert policy_delta > 0

    def test_climate_field_stored(self):
        results = run_simulation(self.scenarios, horizon=3, climate="pessimistic")
        for name, data in results.items():
            assert data["climate"] == "pessimistic"

    def test_co2_offset_in_metrics(self):
        results = run_simulation(self.scenarios, horizon=3)
        for name, data in results.items():
            for row in data["metrics"]:
                assert "co2_offset_tons" in row

    def test_high_risk_wards_non_negative(self):
        results = run_simulation(self.scenarios, horizon=5)
        for name, data in results.items():
            for row in data["metrics"]:
                assert row["high_risk_wards"] >= 0

    def test_empty_scenarios(self):
        results = run_simulation([], horizon=3)
        assert results == {}

    def test_single_baseline_only(self):
        scenarios = [{"name": "Baseline (No Policy)", "interventions": {}}]
        results = run_simulation(scenarios, horizon=3)
        assert len(results) == 1


class TestGenerateCityAnalysis:
    def test_structure(self):
        data = generate_city_analysis()
        assert "ward_risk_scores" in data
        assert "metrics" in data
        assert "city_health_score" in data

    def test_ward_count(self):
        data = generate_city_analysis(n=20)
        assert len(data["ward_risk_scores"]) == 20

    def test_risk_range(self):
        data = generate_city_analysis()
        for w, r in data["ward_risk_scores"].items():
            assert 0.0 < r < 1.0

    def test_health_score_range(self):
        data = generate_city_analysis()
        assert 0 <= data["city_health_score"] <= 100

    def test_deterministic(self):
        d1 = generate_city_analysis(seed=42)
        d2 = generate_city_analysis(seed=42)
        assert d1["ward_risk_scores"] == d2["ward_risk_scores"]

    def test_different_seeds(self):
        d1 = generate_city_analysis(seed=1)
        d2 = generate_city_analysis(seed=2)
        assert d1["ward_risk_scores"] != d2["ward_risk_scores"]


class TestGenerateNDVIHistory:
    def test_length(self):
        df = generate_ndvi_history(n_months=12)
        assert len(df) == 12

    def test_columns(self):
        df = generate_ndvi_history()
        assert "date" in df.columns
        assert "mean_ndvi" in df.columns
        assert "green_pct" in df.columns
        assert "tree_count" in df.columns

    def test_ndvi_positive(self):
        df = generate_ndvi_history()
        assert (df["mean_ndvi"] > 0).all()

    def test_dates_ascending(self):
        df = generate_ndvi_history()
        assert df["date"].is_monotonic_increasing
