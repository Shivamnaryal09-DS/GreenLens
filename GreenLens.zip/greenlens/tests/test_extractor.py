"""
tests/test_extractor.py
───────────────────────
Unit tests for the policy document extractor.
Run with: pytest tests/test_extractor.py -v
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from models.policy_extractor import HeuristicExtractor


@pytest.fixture
def extractor():
    return HeuristicExtractor()


TREE_PLANTING_DOC = """
The Bruhat Bengaluru Mahanagara Palike (BBMP) will plant 50,000 trees across
all wards by 2025. The initiative focuses on native species and will increase
the city's green cover. Ward-12 and Ward-15 are priority zones.
Budget: ₹12 crore allocated for this project.
"""

PARK_CREATION_DOC = """
Under the Namma Green City project, 40 hectares of vacant land will be
converted into public parks. The park creation initiative covers 8 wards
and aims to restore biodiversity in urban areas.
"""

NEUTRAL_DOC = """
The annual budget for the fiscal year 2024-2025 has been approved.
Various departments have submitted their expenditure reports.
"""

NEGATIVE_DOC = """
The proposed road widening will require the removal of 3,000 trees
along the corridor. The felling of heritage trees has been contested
by environmental groups.
"""


class TestEventDetection:
    def test_tree_planting_primary(self, extractor):
        result = extractor.extract(TREE_PLANTING_DOC)
        assert result["primary_event"] == "tree_planting"

    def test_park_creation_primary(self, extractor):
        result = extractor.extract(PARK_CREATION_DOC)
        assert result["primary_event"] == "park_creation"

    def test_unknown_for_neutral(self, extractor):
        result = extractor.extract(NEUTRAL_DOC)
        assert result["primary_event"] == "unknown"

    def test_detected_events_list(self, extractor):
        result = extractor.extract(TREE_PLANTING_DOC)
        assert isinstance(result["detected_events"], list)

    def test_tree_planting_in_detected(self, extractor):
        result = extractor.extract(TREE_PLANTING_DOC)
        assert "tree_planting" in result["detected_events"]


class TestImpactDirection:
    def test_positive_for_planting(self, extractor):
        result = extractor.extract(TREE_PLANTING_DOC)
        assert result["impact_direction"] == "positive"

    def test_positive_for_park(self, extractor):
        result = extractor.extract(PARK_CREATION_DOC)
        assert result["impact_direction"] == "positive"

    def test_negative_for_removal(self, extractor):
        result = extractor.extract(NEGATIVE_DOC)
        assert result["impact_direction"] == "negative"


class TestNumericExtraction:
    def test_trees_mentioned(self, extractor):
        result = extractor.extract(TREE_PLANTING_DOC)
        assert result["trees_mentioned"] == 50000

    def test_area_hectares(self, extractor):
        result = extractor.extract(PARK_CREATION_DOC)
        assert result["area_hectares"] == 40.0

    def test_zero_trees_when_absent(self, extractor):
        result = extractor.extract(NEUTRAL_DOC)
        assert result["trees_mentioned"] == 0

    def test_budget_detected(self, extractor):
        result = extractor.extract(TREE_PLANTING_DOC)
        assert result["budget_mention"] != "not detected"
        assert "12 crore" in result["budget_mention"].lower() or "12" in result["budget_mention"]

    def test_budget_not_detected_when_absent(self, extractor):
        result = extractor.extract(PARK_CREATION_DOC)
        assert result["budget_mention"] == "not detected"


class TestWardAndYearExtraction:
    def test_ward_reference(self, extractor):
        result = extractor.extract(TREE_PLANTING_DOC)
        assert result["ward"] != "not detected"
        assert "12" in result["ward"] or "15" in result["ward"]

    def test_year_references(self, extractor):
        result = extractor.extract(TREE_PLANTING_DOC)
        assert "2025" in result["year_references"]

    def test_no_ward_in_neutral(self, extractor):
        result = extractor.extract(NEUTRAL_DOC)
        # Neutral doc may have year refs but no ward
        assert isinstance(result["year_references"], list)


class TestResultStructure:
    def test_all_fields_present(self, extractor):
        result = extractor.extract(TREE_PLANTING_DOC)
        required = [
            "primary_event", "impact_direction", "detected_events",
            "trees_mentioned", "area_sqm", "area_hectares",
            "ward", "year_references", "budget_mention", "_model",
        ]
        for field in required:
            assert field in result, f"Missing field: {field}"

    def test_model_label(self, extractor):
        result = extractor.extract("test")
        assert result["_model"] == "heuristic"

    def test_empty_string(self, extractor):
        result = extractor.extract("")
        assert result["primary_event"] == "unknown"
        assert result["trees_mentioned"] == 0

    def test_numeric_types(self, extractor):
        result = extractor.extract(TREE_PLANTING_DOC)
        assert isinstance(result["trees_mentioned"], int)
        assert isinstance(result["area_sqm"], float)
        assert isinstance(result["area_hectares"], float)
