"""
tests/test_risk_model.py
────────────────────────
Unit tests for the risk scoring and classification engine.
Run with: pytest tests/test_risk_model.py -v
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from models.risk_model import (
    classify_risk, risk_color, risk_bg_color,
    compute_metrics, rank_wards,
)


class TestClassifyRisk:
    def test_critical(self):
        assert classify_risk(0.80) == "critical"
        assert classify_risk(0.76) == "critical"
        assert classify_risk(1.00) == "critical"

    def test_high(self):
        assert classify_risk(0.60) == "high"
        assert classify_risk(0.51) == "high"
        assert classify_risk(0.75) == "high"

    def test_medium(self):
        assert classify_risk(0.30) == "medium"
        assert classify_risk(0.26) == "medium"
        assert classify_risk(0.50) == "medium"

    def test_low(self):
        assert classify_risk(0.10) == "low"
        assert classify_risk(0.00) == "low"
        assert classify_risk(0.25) == "low"

    def test_boundary_critical(self):
        # Exactly at critical threshold (0.75) → NOT critical → high
        assert classify_risk(0.75) == "high"

    def test_boundary_high(self):
        # Exactly at high threshold (0.50) → NOT high → medium
        assert classify_risk(0.50) == "medium"


class TestRiskColors:
    def test_returns_hex(self):
        for score in [0.1, 0.3, 0.6, 0.9]:
            color = risk_color(score)
            assert color.startswith("#")
            assert len(color) == 7

    def test_critical_is_red(self):
        assert risk_color(0.9) == "#c62828"

    def test_low_is_green(self):
        assert risk_color(0.1) == "#2e7d32"


class TestComputeMetrics:
    def setup_method(self):
        self.ward_risks = {
            "Ward-00": 0.80,  # critical
            "Ward-01": 0.60,  # high
            "Ward-02": 0.40,  # medium
            "Ward-03": 0.10,  # low
            "Ward-04": 0.20,  # low
        }

    def test_critical_count(self):
        m = compute_metrics(self.ward_risks)
        assert m["critical_wards"] == 1

    def test_high_risk_count(self):
        m = compute_metrics(self.ward_risks)
        assert m["high_risk_wards"] == 2  # > 0.50

    def test_total_wards(self):
        m = compute_metrics(self.ward_risks)
        assert m["total_wards"] == 5

    def test_worst_ward(self):
        m = compute_metrics(self.ward_risks)
        assert m["worst_ward"] == "Ward-00"

    def test_best_ward(self):
        m = compute_metrics(self.ward_risks)
        assert m["best_ward"] == "Ward-03"

    def test_health_score_range(self):
        m = compute_metrics(self.ward_risks)
        assert 0 <= m["overall_health_score"] <= 100

    def test_pct_at_risk(self):
        m = compute_metrics(self.ward_risks)
        # 2 out of 5 wards are > 0.50
        assert abs(m["pct_wards_at_risk"] - 40.0) < 0.1


class TestRankWards:
    def setup_method(self):
        self.ward_risks = {
            "Ward-A": 0.30,
            "Ward-B": 0.80,
            "Ward-C": 0.55,
        }

    def test_descending_order(self):
        ranked = rank_wards(self.ward_risks, ascending=False)
        scores = [r[1] for r in ranked]
        assert scores == sorted(scores, reverse=True)

    def test_ascending_order(self):
        ranked = rank_wards(self.ward_risks, ascending=True)
        scores = [r[1] for r in ranked]
        assert scores == sorted(scores)

    def test_returns_level(self):
        ranked = rank_wards(self.ward_risks)
        for name, score, level in ranked:
            assert level in ("critical", "high", "medium", "low")

    def test_count(self):
        ranked = rank_wards(self.ward_risks)
        assert len(ranked) == 3
