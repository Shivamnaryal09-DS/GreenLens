"""
pages/upload.py
───────────────
📄 Upload Policy Page — PDF/TXT/CSV extractor.
"""

import streamlit as st

from data.loaders import extract_text_from_upload, top_words
from models.policy_extractor import HeuristicExtractor
from utils.styling import section_header, page_header, info_box, extract_row
from utils.charts import word_freq_bar
from utils.exports import to_json


def render():
    page_header(
        "Upload Policy Document",
        "Extract green-cover signals from PDF · TXT · CSV · XLSX policy documents",
    )

    uploaded = st.file_uploader(
        "Upload document",
        type=["pdf", "txt", "csv", "xlsx"],
        label_visibility="collapsed",
        help="Max 32 MB",
    )

    if uploaded is None:
        st.markdown("""
        <div class="upload-placeholder">
            <h3>📂 Drop a file to begin</h3>
            <p>Government policy PDF, urban master plan, or green-cover initiative document.</p>
            <p style="font-size:0.76rem; margin-top:1rem; font-family:monospace; color:#9e9e9e">
                .pdf &nbsp;·&nbsp; .txt &nbsp;·&nbsp; .csv &nbsp;·&nbsp; .xlsx
            </p>
        </div>
        """, unsafe_allow_html=True)
        return

    # ── Extract Text ──────────────────────────────────────────────
    with st.spinner("Extracting text…"):
        text, file_type, count = extract_text_from_upload(uploaded)

    label_map = {"pdf": "pages", "csv": "rows", "xlsx": "rows", "txt": "lines"}
    st.success(
        f"✅  `{uploaded.name}`  ·  **{len(text):,}** characters  ·  "
        f"{count} {label_map.get(file_type, 'units')}"
    )

    col1, col2 = st.columns([1, 1])

    with col1:
        st.markdown(section_header("Text Preview"), unsafe_allow_html=True)
        st.text_area("", text[:1500] or "(empty)", height=290, disabled=True,
                     label_visibility="collapsed")

        wf_df = top_words(text, n=15)
        if not wf_df.empty:
            st.markdown(section_header("Top Terms"), unsafe_allow_html=True)
            st.plotly_chart(
                word_freq_bar(wf_df, height=220),
                use_container_width=True,
                config={"displayModeBar": False},
            )

    with col2:
        st.markdown(section_header("Extraction Results"), unsafe_allow_html=True)

        with st.spinner("Running extractor…"):
            result = HeuristicExtractor().extract(text)

        fields = [
            ("Primary Event",    result.get("primary_event",    "—")),
            ("Impact Direction", result.get("impact_direction",  "—")),
            ("Trees Mentioned",  result.get("trees_mentioned",   0)),
            ("Planting Target",  result.get("planting_target",   0)),
            ("Area (hectares)",  result.get("area_hectares",     0.0)),
            ("Ward Reference",   result.get("ward",              "—")),
            ("Budget Mention",   result.get("budget_mention",    "—")),
            ("Year References",  ", ".join(result.get("year_references", [])) or "—"),
        ]
        st.markdown("".join(extract_row(l, v) for l, v in fields), unsafe_allow_html=True)

        st.markdown("**Detected Event Types:**")
        events = result.get("detected_events", [])
        if events and events != ["not detected"]:
            badges = " ".join(
                f'<span class="badge badge-low">✓ {ev}</span>' for ev in events
            )
            st.markdown(badges, unsafe_allow_html=True)
        else:
            st.markdown("_No specific event types detected_")

        st.markdown("---")
        st.caption(f"Model: `heuristic`")

        st.download_button(
            "⬇  Download Extracted Data (JSON)",
            data=to_json({
                "file": uploaded.name,
                "char_count": len(text),
                **{k: v for k, v in result.items() if not k.startswith("_")},
            }),
            file_name="policy_extraction.json",
            mime="application/json",
        )
