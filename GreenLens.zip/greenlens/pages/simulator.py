"""
pages/simulator.py
──────────────────
🔬 Policy Simulator — Multi-scenario counterfactual simulation.
"""

import streamlit as st
import pandas as pd

from config.settings import (
    INTERVENTION_REGISTRY, CLIMATE_SCENARIOS,
    SIM_DEFAULT_HORIZON, SIM_MAX_HORIZON, SIM_BASE_YEAR,
)
from data.generators import run_simulation
from utils.styling import section_header, page_header, info_box, warn_box
from utils.charts import ndvi_line_chart, high_risk_wards_line, green_cover_area, tree_count_bar
from utils.exports import to_json, simulation_to_csv


def render():
    city_cfg = st.session_state.get("city_cfg", {"label": "Bengaluru, India"})

    page_header(
        "Policy Simulator",
        f"Counterfactual scenario comparison  ·  {city_cfg['label']}",
    )

    # ── Configuration ─────────────────────────────────────────────
    st.markdown(section_header("Simulation Configuration"), unsafe_allow_html=True)
    cfg1, cfg2, cfg3 = st.columns(3)
    with cfg1:
        horizon = st.slider("Horizon (years)", 2, SIM_MAX_HORIZON, SIM_DEFAULT_HORIZON)
    with cfg2:
        climate = st.selectbox("Climate Scenario", CLIMATE_SCENARIOS)
    with cfg3:
        n_scenarios = st.number_input("Policy Scenarios", 1, 4, 2, 1)

    climate_notes = {
        "moderate":    "Baseline climate — no extreme weather amplification.",
        "optimistic":  "Favourable rainfall, reduced heat. Greening ×1.25.",
        "pessimistic": "Drought & heat stress. Policy effectiveness ×0.70.",
    }
    info_box(f"🌤️ <b>{climate.title()}</b>: {climate_notes[climate]}")

    # ── Scenario Builder ──────────────────────────────────────────
    st.markdown(section_header("Define Scenarios", margin_top="1rem"), unsafe_allow_html=True)
    scenarios = [{"name": "Baseline (No Policy)", "interventions": {}}]

    for i in range(int(n_scenarios)):
        with st.expander(f"📌 Scenario {i + 1}", expanded=(i == 0)):
            c1, c2 = st.columns(2)
            with c1:
                name = st.text_input("Scenario name",
                                     value=f"Scenario {i + 1} — Green Push",
                                     key=f"sname_{i}")
            with c2:
                interv_type = st.selectbox(
                    "Intervention type",
                    list(INTERVENTION_REGISTRY.keys()),
                    format_func=lambda k: INTERVENTION_REGISTRY[k]["label"],
                    key=f"itype_{i}",
                )

            reg = INTERVENTION_REGISTRY[interv_type]
            magnitude = st.number_input(
                f"Magnitude  ({reg['unit']})",
                value=reg["default_mag"], min_value=100.0,
                max_value=500_000.0, step=500.0, key=f"imag_{i}",
            )
            st.caption(f"{reg['description']}")

            scenarios.append({
                "name": name,
                "interventions": {
                    str(yr): [{"type": interv_type, "magnitude": magnitude}]
                    for yr in range(SIM_BASE_YEAR, SIM_BASE_YEAR + horizon)
                },
            })

    st.markdown("---")
    run = st.button("▶  Run Simulation", type="primary", use_container_width=True)

    if not run:
        warn_box("Configure scenarios above and click <b>Run Simulation</b>.")
        return

    # ── Run ───────────────────────────────────────────────────────
    with st.spinner("Running simulations…"):
        results = run_simulation(scenarios, horizon=horizon, climate=climate)

    st.success(f"✅  {len(results)} scenarios · {horizon} years · {climate} climate", icon="🌿")
    st.markdown("---")
    st.markdown(section_header("Results"), unsafe_allow_html=True)

    # NDVI Trajectory
    ndvi_df = pd.DataFrame({
        name: {row["year"]: row["mean_ndvi"] for row in sdata["metrics"]}
        for name, sdata in results.items()
    })
    st.markdown("#### 🌱 NDVI Trajectory")
    st.plotly_chart(ndvi_line_chart(ndvi_df), use_container_width=True)

    tab1, tab2, tab3 = st.tabs(["⚠️ High-Risk Wards", "🌳 Green Cover %", "🌲 Tree Count"])

    with tab1:
        hrw_df = pd.DataFrame({
            name: {row["year"]: row["high_risk_wards"] for row in sdata["metrics"]}
            for name, sdata in results.items()
        })
        st.plotly_chart(high_risk_wards_line(hrw_df), use_container_width=True)

    with tab2:
        gc_df = pd.DataFrame({
            name: {row["year"]: row["mean_green_pct"] for row in sdata["metrics"]}
            for name, sdata in results.items()
        })
        st.plotly_chart(green_cover_area(gc_df), use_container_width=True)

    with tab3:
        st.plotly_chart(tree_count_bar(results), use_container_width=True)

    # Summary Table
    st.markdown("#### 📋 Final Year Summary")
    rows = []
    for name, sdata in results.items():
        final = sdata["metrics"][-1]
        rows.append({
            "Scenario":        name,
            "Final NDVI":      f"{final['mean_ndvi']:.4f}",
            "Δ vs Baseline":   f"{sdata['delta_ndvi_vs_baseline']:+.4f}",
            "% Improvement":   f"{sdata['pct_improvement']:+.2f}%",
            "High-Risk Wards": final["high_risk_wards"],
            "Total Trees":     f"{final['total_tree_count']:,}",
        })
    st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)

    # Downloads
    st.markdown("---")
    dl1, dl2 = st.columns(2)
    with dl1:
        st.download_button("⬇  Results (JSON)", data=to_json(results),
                           file_name="simulation_results.json", mime="application/json")
    with dl2:
        st.download_button("⬇  Metrics (CSV)", data=simulation_to_csv(results),
                           file_name="simulation_metrics.csv", mime="text/csv")
