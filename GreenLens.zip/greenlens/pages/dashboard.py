"""
pages/dashboard.py
──────────────────
📊 Dashboard Page — City KPIs, ward risk distribution, full table.
"""

import streamlit as st
import pandas as pd

from data.generators import generate_city_analysis
from models.risk_model import cell_style, classify_risk
from utils.styling import metric_card, section_header, page_header, info_box
from utils.charts import ward_risk_bar, risk_donut
from utils.exports import ward_df_to_csv


@st.cache_data
def _get_data(city_key: str, n_wards: int, seed: int):
    return generate_city_analysis(n=n_wards, seed=seed)


def render():
    city_cfg  = st.session_state.get("city_cfg", {"label": "Bengaluru, India", "n_wards": 30, "seed": 99})
    city_key  = st.session_state.get("city_key", "Bengaluru")

    page_header(
        "GreenLens — Dashboard",
        f"Multi-modal green cover risk analysis  ·  {city_cfg['label']}  ·  2024-01",
    )

    data = _get_data(city_key, city_cfg["n_wards"], city_cfg["seed"])
    m    = data["metrics"]

    # ── KPI Row ───────────────────────────────────────────────────
    kpis = [
        ("Health Score",     f"{m['overall_health_score']}",  "/100",         "#2e7d32"),
        ("Critical Wards",   str(m["critical_wards"]),        "risk > 0.75",  "#c62828"),
        ("High-Risk Wards",  str(m["high_risk_wards"]),       "risk > 0.50",  "#e65100"),
        ("% At Risk",        f"{m['pct_wards_at_risk']}%",    "risk > 0.50",  "#f57f17"),
        ("Total Wards",      str(m["total_wards"]),           "analysed",     "#455a64"),
    ]
    cols = st.columns(5)
    for col, (label, val, sub, color) in zip(cols, kpis):
        with col:
            st.markdown(metric_card(label, val, sub, color), unsafe_allow_html=True)

    st.markdown("---")

    # ── Charts Row ────────────────────────────────────────────────
    left, right = st.columns([3, 2])

    with left:
        st.markdown(section_header("Ward Risk Distribution"), unsafe_allow_html=True)
        ward_df = (
            pd.DataFrame(
                [{"Ward": w, "Risk Score": r} for w, r in data["ward_risk_scores"].items()]
            )
            .sort_values("Risk Score", ascending=False)
            .reset_index(drop=True)
        )
        fig = ward_risk_bar(ward_df, height=320)
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

    with right:
        st.markdown(section_header("Risk Tier Distribution"), unsafe_allow_html=True)
        fig_donut = risk_donut(m, height=270)
        st.plotly_chart(fig_donut, use_container_width=True, config={"displayModeBar": False})

    # ── Summary Row ───────────────────────────────────────────────
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown(section_header("Key Wards"), unsafe_allow_html=True)
        st.markdown(f"🔴 **Worst Ward:** `{m['worst_ward']}`")
        st.markdown(f"🟢 **Best Ward:** `{m['best_ward']}`")
        st.markdown(f"📊 **Std Deviation:** `{m.get('std_risk', 'N/A')}`")

    with c2:
        st.markdown(section_header("Tier Breakdown"), unsafe_allow_html=True)
        breakdown_df = pd.DataFrame({
            "Tier":      ["🔴 Critical", "🟠 High", "🟡 Medium", "🟢 Low"],
            "Wards":     [
                m["critical_wards"],
                m["high_risk_wards"] - m["critical_wards"],
                m["medium_risk_wards"],
                m["low_risk_wards"],
            ],
            "Threshold": ["> 0.75", "0.50–0.75", "0.25–0.50", "< 0.25"],
        })
        st.dataframe(breakdown_df, hide_index=True, use_container_width=True)

    with c3:
        st.markdown(section_header("Hotspot Wards"), unsafe_allow_html=True)
        if data["hotspot_wards"]:
            info_box(
                "⚠️ " + "  ·  ".join(data["hotspot_wards"][:6]) +
                ("  …" if len(data["hotspot_wards"]) > 6 else "")
            )
            st.caption(f"{len(data['hotspot_wards'])} wards above critical threshold (0.75)")
        else:
            st.success("No hotspot wards detected.")

    # ── Full Table ────────────────────────────────────────────────
    st.markdown("---")
    st.markdown(section_header("All Wards — Detailed Risk Scores"), unsafe_allow_html=True)

    ward_df["Risk Level"] = ward_df["Risk Score"].apply(lambda v: classify_risk(v).title())
    styled = (
        ward_df.style
        .map(cell_style, subset=["Risk Score"])
        .format({"Risk Score": "{:.3f}"})
    )
    st.dataframe(styled, use_container_width=True, height=360, hide_index=True)

    # ── Downloads ─────────────────────────────────────────────────
    col1, col2 = st.columns(2)
    with col1:
        st.download_button(
            "⬇  Download Ward Data (CSV)",
            data=ward_df_to_csv(data["ward_risk_scores"]),
            file_name=f"ward_risk_scores_{city_key}.csv",
            mime="text/csv",
        )
    with col2:
        import json
        st.download_button(
            "⬇  Download Analysis (JSON)",
            data=json.dumps(data, indent=2),
            file_name=f"city_analysis_{city_key}.json",
            mime="application/json",
        )
