"""
pages/settings.py
─────────────────
⚙️ Settings Page — Risk thresholds & app info.
"""

import streamlit as st
import json

from config import settings as cfg
from utils.styling import section_header, page_header, info_box, warn_box


def render():
    page_header(
        "Settings",
        "Adjust risk thresholds and simulation defaults",
    )

    # ── Risk Thresholds ───────────────────────────────────────────
    st.markdown(section_header("Risk Threshold Configuration"), unsafe_allow_html=True)
    info_box("ℹ️ Changes are saved to session and applied on next page load.")

    col_a, col_b, col_c = st.columns(3)
    with col_a:
        critical_thresh = st.slider("🔴 Critical", 0.5, 0.99,
                                    cfg.RISK_THRESHOLDS["critical"], 0.05)
    with col_b:
        high_thresh = st.slider("🟠 High", 0.3, 0.8,
                                cfg.RISK_THRESHOLDS["high"], 0.05)
    with col_c:
        medium_thresh = st.slider("🟡 Medium", 0.1, 0.5,
                                  cfg.RISK_THRESHOLDS["medium"], 0.05)

    if critical_thresh <= high_thresh:
        warn_box("⚠️ Critical threshold must be greater than High.")
    if high_thresh <= medium_thresh:
        warn_box("⚠️ High threshold must be greater than Medium.")

    # ── Simulation Defaults ───────────────────────────────────────
    st.markdown("---")
    st.markdown(section_header("Simulation Defaults"), unsafe_allow_html=True)
    col1, col2 = st.columns(2)
    with col1:
        default_horizon = st.slider("Default Horizon (years)", 2, 10, cfg.SIM_DEFAULT_HORIZON)
    with col2:
        default_climate = st.selectbox("Default Climate", cfg.CLIMATE_SCENARIOS,
                                       index=cfg.CLIMATE_SCENARIOS.index("moderate"))

    # ── About ─────────────────────────────────────────────────────
    st.markdown("---")
    st.markdown(section_header("About GreenLens"), unsafe_allow_html=True)

    c1, c2, c3 = st.columns(3)
    c1.metric("Version",  cfg.APP_VERSION)
    c2.metric("Cities",   "7 supported")
    c3.metric("Mode",     "Demo / Synthetic")

    st.markdown("""
    <div style="background:white; border-radius:12px; padding:1.2rem 1.5rem;
         box-shadow:0 1px 4px rgba(0,0,0,0.06); margin-top:0.5rem;">
        <p style="color:#616161; font-size:0.83rem; line-height:1.8; margin:0">
            <b>GreenLens</b> monitors, simulates, and reports on urban green cover health
            across Indian cities. Built on synthetic data for demonstration. In production,
            connect to real satellite imagery pipelines (e.g. Google Earth Engine, Sentinel-2)
            and municipal ward databases.
        </p>
    </div>
    """, unsafe_allow_html=True)

    # ── Save ──────────────────────────────────────────────────────
    st.markdown("---")
    col_save, col_reset = st.columns(2)
    with col_save:
        if st.button("💾  Save Configuration", type="primary", use_container_width=True):
            st.session_state["config"] = {
                "risk_thresholds": {
                    "critical": critical_thresh,
                    "high":     high_thresh,
                    "medium":   medium_thresh,
                },
                "simulation": {
                    "default_horizon": default_horizon,
                    "default_climate": default_climate,
                },
            }
            st.success("✅ Configuration saved to session.")

    with col_reset:
        if st.button("🔄  Reset to Defaults", use_container_width=True):
            st.session_state.pop("config", None)
            st.success("Reset to defaults.")
            st.rerun()
