"""
pages/risk_map.py
─────────────────
🗺️ Risk Map Page — Interactive scatter map with threshold filter.
"""

import streamlit as st
import pandas as pd

from data.generators import generate_city_analysis, generate_ward_geodata
from utils.styling import section_header, page_header, info_box
from utils.exports import ward_df_to_csv


@st.cache_data
def _get_map_data(city_key: str, n_wards: int, seed: int, city_lat: float, city_lon: float):
    data   = generate_city_analysis(n=n_wards, seed=seed)
    geo_df = generate_ward_geodata(data["ward_risk_scores"], city_lat=city_lat, city_lon=city_lon)
    return data, geo_df


def render():
    city_cfg = st.session_state.get("city_cfg", {"label": "Bengaluru, India", "n_wards": 30, "seed": 99, "lat": 12.9716, "lon": 77.5946})
    city_key = st.session_state.get("city_key", "Bengaluru")

    page_header(
        "Interactive Risk Map",
        f"Ward-level green cover risk  ·  {city_cfg['label']}  ·  Scatter map (synthetic coordinates)",
    )

    data, map_df = _get_map_data(city_key, city_cfg["n_wards"], city_cfg["seed"], city_cfg["lat"], city_cfg["lon"])
    m = data["metrics"]

    # ── Map ───────────────────────────────────────────────────────
    st.map(
        map_df,
        latitude="lat",
        longitude="lon",
        size="size",
        color="color",
        zoom=10,
    )

    st.markdown("---")
    left, right = st.columns([3, 2])

    with left:
        st.markdown(section_header("Filter Wards by Risk Threshold"), unsafe_allow_html=True)
        threshold = st.slider(
            "Minimum risk score to display",
            min_value=0.0, max_value=1.0,
            value=0.50, step=0.05,
        )
        filtered = (
            map_df[map_df["risk"] >= threshold][["ward", "risk"]]
            .sort_values("risk", ascending=False)
            .rename(columns={"ward": "Ward", "risk": "Risk Score"})
        )
        info_box(
            f"Showing <strong>{len(filtered)}</strong> wards at or above "
            f"risk threshold <strong>{threshold:.2f}</strong>"
        )
        st.dataframe(
            filtered.style.format({"Risk Score": "{:.3f}"}),
            use_container_width=True,
            hide_index=True,
            height=300,
        )
        st.download_button(
            "⬇  Download Filtered Wards (CSV)",
            data=filtered.to_csv(index=False),
            file_name=f"wards_risk_above_{threshold:.2f}_{city_key}.csv",
            mime="text/csv",
        )

    with right:
        st.markdown(section_header("Map Legend"), unsafe_allow_html=True)
        legend = [
            ("#c62828", "🔴 Critical", "> 0.75"),
            ("#e65100", "🟠 High",     "0.50 – 0.75"),
            ("#f57f17", "🟡 Medium",   "0.25 – 0.50"),
            ("#2e7d32", "🟢 Low",      "< 0.25"),
        ]
        for color, label, rng in legend:
            st.markdown(
                f"<span style='color:{color}; font-weight:700; font-size:1.1rem'>■</span>"
                f"&nbsp;<b>{label}</b>&nbsp;"
                f"<span style='color:#9e9e9e; font-size:0.78rem'>({rng})</span>",
                unsafe_allow_html=True,
            )

        st.markdown("---")

        col_a, col_b = st.columns(2)
        col_a.metric("Mean Risk",       f"{data['mean_risk']:.3f}")
        col_b.metric("Health Score",    f"{data['city_health_score']}/100")
        col_a.metric("Critical Wards",  m["critical_wards"])
        col_b.metric("High Risk Wards", m["high_risk_wards"])
        col_a.metric("Total Wards",     m["total_wards"])
        col_b.metric("% At Risk",       f"{m['pct_wards_at_risk']}%")

        st.markdown("---")
        st.markdown(
            '<div class="sidebar-meta" style="color:#9e9e9e !important; font-size:0.72rem">'
            "ℹ️ Dot size ∝ risk magnitude<br>"
            "Colour = risk tier<br>"
            "Coordinates are synthetic/demo"
            "</div>",
            unsafe_allow_html=True,
        )
