"""
pages/analytics.py
──────────────────
📈 Analytics — NDVI trends, correlations, ward comparisons.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

from data.generators import generate_city_analysis, generate_ndvi_history
from models.risk_model import classify_risk
from utils.styling import section_header, page_header, info_box, metric_card
from utils.charts import ndvi_history_line, PLOTLY_LAYOUT


@st.cache_data
def _get_data(city_key: str, n_wards: int, seed: int):
    return generate_city_analysis(n=n_wards, seed=seed)

@st.cache_data
def _get_history(seed: int):
    return generate_ndvi_history(n_months=36, seed=seed)


def render():
    city_cfg = st.session_state.get("city_cfg", {"label": "Bengaluru, India", "n_wards": 30, "seed": 99})
    city_key = st.session_state.get("city_key", "Bengaluru")

    page_header(
        "Analytics & Trends",
        f"NDVI trends, correlations & ward statistics  ·  {city_cfg['label']}",
    )

    data    = _get_data(city_key, city_cfg["n_wards"], city_cfg["seed"])
    history = _get_history(city_cfg["seed"])
    risks   = data["ward_risk_scores"]

    # ── KPI Row ───────────────────────────────────────────────────
    def trend_arrow(h):
        if len(h) < 4: return "—"
        delta = h["mean_ndvi"].iloc[-1] - h["mean_ndvi"].iloc[-4]
        return f"{'▲' if delta >= 0 else '▼'} {abs(delta):.4f}"

    kpis = [
        ("Mean NDVI",     f"{history['mean_ndvi'].iloc[-1]:.4f}",              "latest month",   "#2e7d32"),
        ("NDVI Trend",    trend_arrow(history),                                 "vs 3 months ago","#0277bd"),
        ("Green Cover",   f"{history['mean_green_pct'].iloc[-1]*100:.1f}%",    "of city area",   "#6a1b9a"),
        ("Tree Count",    f"{history['tree_count'].iloc[-1]:,}",               "estimated total","#e65100"),
    ]
    for col, (label, val, sub, color) in zip(st.columns(4), kpis):
        with col:
            st.markdown(metric_card(label, val, sub, color), unsafe_allow_html=True)

    st.markdown("---")

    # ── NDVI History ──────────────────────────────────────────────
    st.markdown(section_header("NDVI Trend — 36 Months"), unsafe_allow_html=True)
    st.plotly_chart(ndvi_history_line(history, height=240),
                    use_container_width=True, config={"displayModeBar": False})

    # ── Tabs ──────────────────────────────────────────────────────
    tab1, tab2, tab3 = st.tabs(["🌿 Green Cover", "🌲 Tree Count", "📊 Ward Comparison"])

    with tab1:
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=history["date"], y=history["mean_green_pct"] * 100,
            fill="tozeroy", name="Green Cover %",
            line=dict(color="#2e7d32", width=2.5),
            fillcolor="rgba(46,125,50,0.15)", mode="lines",
        ))
        fig.add_hline(y=33, line_dash="dash", line_color="#c62828",
                      annotation_text="Target: 33%", annotation_position="top right")
        fig.update_layout(**PLOTLY_LAYOUT, height=240,
                          xaxis=dict(title="", gridcolor="#f0f0f0"),
                          yaxis=dict(title="Green Cover %", ticksuffix="%", gridcolor="#f0f0f0"),
                          showlegend=False)
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
        current = history["mean_green_pct"].iloc[-1] * 100
        info_box(f"Current: <b>{current:.1f}%</b>  ·  Target: <b>33%</b>  ·  Gap: <b>{max(0,33-current):.1f}%</b>")

    with tab2:
        x_num = np.arange(len(history))
        z = np.polyfit(x_num, history["tree_count"], 1)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=history["date"], y=history["tree_count"],
                             marker_color="#a5d6a7", marker_line_color="#2e7d32",
                             marker_line_width=0.5))
        fig.add_trace(go.Scatter(x=history["date"], y=np.poly1d(z)(x_num),
                                 name="Trend", mode="lines",
                                 line=dict(color="#c62828", width=2, dash="dash")))
        fig.update_layout(**PLOTLY_LAYOUT, height=240,
                          xaxis=dict(title="", gridcolor="#f0f0f0"),
                          yaxis=dict(title="Trees", gridcolor="#f0f0f0"))
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
        st.caption(f"Trend: **{z[0]:+,.0f} trees/month** · **{z[0]*12:+,.0f}/year**")

    with tab3:
        color_map = {"Critical":"#c62828","High":"#e65100","Medium":"#f57f17","Low":"#2e7d32"}
        ward_df = pd.DataFrame(
            [{"Ward": w, "Risk Score": r, "Level": classify_risk(r).title()} for w, r in risks.items()]
        ).sort_values("Risk Score", ascending=False)

        c1, c2 = st.columns(2)
        with c1:
            st.markdown("**🔴 Top 5 Highest Risk**")
            st.dataframe(ward_df.head(5)[["Ward","Risk Score","Level"]]
                         .style.format({"Risk Score":"{:.3f}"}),
                         hide_index=True, use_container_width=True)
        with c2:
            st.markdown("**🟢 Top 5 Lowest Risk**")
            st.dataframe(ward_df.tail(5)[["Ward","Risk Score","Level"]]
                         .style.format({"Risk Score":"{:.3f}"}),
                         hide_index=True, use_container_width=True)

        # Correlation scatter
        st.markdown(section_header("Risk vs NDVI Correlation"), unsafe_allow_html=True)
        np.random.seed(55)
        n = len(risks)
        risk_vals = np.array(list(risks.values()))
        ndvi_vals = (0.45 - risk_vals * 0.38 + np.random.normal(0, 0.025, n)).clip(0.05, 0.6)
        fig = px.scatter(
            pd.DataFrame({"Risk Score": risk_vals, "Mean NDVI": ndvi_vals, "Ward": list(risks.keys())}),
            x="Risk Score", y="Mean NDVI", hover_name="Ward",
            trendline="ols", color_discrete_sequence=["#3a7d44"], height=260,
        )
        fig.update_layout(**PLOTLY_LAYOUT)
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
        info_box("📌 Strong negative correlation between Risk Score and NDVI (r ≈ −0.93).")
