"""
data/generators.py
──────────────────
Synthetic data generators for demo mode.
All generators are deterministic (seeded) so results are reproducible.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple

from config.settings import (
    CITY_LAT, CITY_LON, DEMO_SEED, N_WARDS,
    SIM_BASE_YEAR, SIM_BASELINE_NDVI, SIM_SEED,
    RISK_THRESHOLDS, INTERVENTION_REGISTRY,
)


# ── Ward Risk Data ────────────────────────────────────────────────

def generate_ward_risks(n: int = N_WARDS, seed: int = DEMO_SEED) -> Dict[str, float]:
    """Return {ward_id: risk_score} for n wards, risk in [0.05, 0.95]."""
    np.random.seed(seed)
    wards = [f"Ward-{i:02d}" for i in range(n)]
    risks = np.clip(np.random.beta(2, 3, n), 0.05, 0.95)
    return {w: round(float(r), 3) for w, r in zip(wards, risks)}


def generate_city_analysis(n: int = N_WARDS, seed: int = DEMO_SEED) -> Dict:
    """Full city analysis dict matching the app's data contract."""
    np.random.seed(seed)
    ward_risks = generate_ward_risks(n, seed)
    risks_arr = np.array(list(ward_risks.values()))

    return {
        "city":             "Bengaluru, India",
        "analysis_date":    "2024-01",
        "ward_risk_scores": ward_risks,
        "city_health_score": round(float(100 * (1 - risks_arr.mean())), 1),
        "hotspot_wards":    [w for w, r in ward_risks.items() if r > RISK_THRESHOLDS["critical"]],
        "mean_risk":        round(float(risks_arr.mean()), 3),
        "metrics": {
            "overall_health_score": round(float(100 * (1 - risks_arr.mean())), 1),
            "critical_wards":   int((risks_arr > RISK_THRESHOLDS["critical"]).sum()),
            "high_risk_wards":  int((risks_arr > RISK_THRESHOLDS["high"]).sum()),
            "medium_risk_wards":int(((risks_arr > RISK_THRESHOLDS["medium"]) & (risks_arr <= RISK_THRESHOLDS["high"])).sum()),
            "low_risk_wards":   int((risks_arr <= RISK_THRESHOLDS["medium"]).sum()),
            "total_wards":      n,
            "pct_wards_at_risk": round(float((risks_arr > RISK_THRESHOLDS["high"]).mean() * 100), 1),
            "worst_ward":       list(ward_risks.keys())[int(risks_arr.argmax())],
            "best_ward":        list(ward_risks.keys())[int(risks_arr.argmin())],
            "std_risk":         round(float(risks_arr.std()), 3),
        },
    }


def generate_ward_geodata(ward_risks: Dict[str, float], seed: int = 42,
                          city_lat: float = CITY_LAT, city_lon: float = CITY_LON) -> pd.DataFrame:
    """Scatter coordinates around city centre for map rendering."""
    np.random.seed(seed)
    n = len(ward_risks)
    wards  = list(ward_risks.keys())
    risks  = list(ward_risks.values())
    lats   = city_lat + np.random.uniform(-0.25, 0.25, n)
    lons   = city_lon + np.random.uniform(-0.25, 0.25, n)

    def rgba(r):
        if r > 0.75:   return [198, 40, 40, 210]
        elif r > 0.50: return [230, 81,  0, 185]
        elif r > 0.25: return [245, 127, 23, 160]
        else:          return [46, 125, 50, 140]

    return pd.DataFrame({
        "ward":  wards,
        "lat":   lats,
        "lon":   lons,
        "risk":  risks,
        "size":  [max(60, int(r * 450)) for r in risks],
        "color": [rgba(r) for r in risks],
    })


# ── NDVI Time-Series ──────────────────────────────────────────────

def generate_ndvi_history(
    n_months: int = 24,
    seed: int = DEMO_SEED,
) -> pd.DataFrame:
    """Generate synthetic monthly NDVI history for trend analysis."""
    np.random.seed(seed)
    dates = pd.date_range(end="2024-01-01", periods=n_months, freq="MS")
    base  = SIM_BASELINE_NDVI
    ndvi  = [base + i * 0.001 + np.random.normal(0, 0.008) for i in range(n_months)]
    green_pct = [max(0.05, v * 0.7 + np.random.normal(0, 0.005)) for v in ndvi]
    tree_count = [int(18000 + i * 80 + np.random.randint(-200, 200)) for i in range(n_months)]

    return pd.DataFrame({
        "date":       dates,
        "mean_ndvi":  [round(v, 4) for v in ndvi],
        "mean_green_pct":  [round(v, 4) for v in green_pct],
        "tree_count": tree_count,
    })


# ── Simulation ────────────────────────────────────────────────────

def run_simulation(
    scenarios_cfg: List[Dict],
    horizon: int = 5,
    climate: str = "moderate",
) -> Dict:
    """
    Counterfactual simulation engine.
    Returns dict keyed by scenario name containing yearly metrics.
    """
    np.random.seed(SIM_SEED)
    base_year = SIM_BASE_YEAR
    years     = list(range(base_year, base_year + horizon))
    results   = {}

    # Climate multipliers
    climate_mult = {"moderate": 1.0, "optimistic": 1.25, "pessimistic": 0.70}
    mult = climate_mult.get(climate, 1.0)

    for s in scenarios_cfg:
        name    = s["name"]
        is_base = "baseline" in name.lower() or "no policy" in name.lower()

        metrics = []
        ndvi = SIM_BASELINE_NDVI if is_base else SIM_BASELINE_NDVI + np.random.uniform(0.005, 0.02)

        for t, yr in enumerate(years):
            if is_base:
                delta = -0.008 * mult
            else:
                delta = np.random.uniform(-0.002, 0.012) * mult

            ndvi = max(0.05, ndvi + delta)
            metrics.append({
                "year":            yr,
                "mean_ndvi":       round(float(ndvi), 4),
                "mean_green_pct":  round(float(ndvi * 0.7), 4),
                "total_tree_count":int(20_000 + t * (0 if is_base else 10_000)),
                "high_risk_wards": max(0, 12 - t * (0 if is_base else 1)),
                "co2_offset_tons": round(float((ndvi * 0.7) * 1_500_000 * 0.0002), 1),
                "temp_reduction_c":round(float(ndvi * 2.1), 2),
            })

        baseline_info  = results.get("Baseline (No Policy)")
        baseline_final = (
            baseline_info["metrics"][-1]["mean_ndvi"]
            if baseline_info else SIM_BASELINE_NDVI
        )
        final_ndvi = metrics[-1]["mean_ndvi"]

        # Baseline delta vs itself is 0 by definition
        delta = 0.0 if is_base else round(final_ndvi - baseline_final, 4)

        results[name] = {
            "metrics":               metrics,
            "scenario_config":       s,
            "delta_ndvi_vs_baseline":delta,
            "pct_improvement":       round((final_ndvi - SIM_BASELINE_NDVI) / SIM_BASELINE_NDVI * 100, 2),
            "climate":               climate,
        }

    return results
