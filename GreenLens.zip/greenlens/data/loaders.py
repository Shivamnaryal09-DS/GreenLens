"""
data/loaders.py
───────────────
File and data loading utilities.
Handles PDF, TXT, CSV, XLSX parsing and normalization.
"""

from __future__ import annotations

import io
import re
from collections import Counter
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


# ── Text Extraction ───────────────────────────────────────────────

def extract_text_from_upload(uploaded_file) -> Tuple[str, str, int]:
    """
    Extract text content from a Streamlit UploadedFile object.

    Returns:
        (text, file_type, page_or_row_count)
    """
    name = uploaded_file.name
    ext  = name.rsplit(".", 1)[-1].lower()

    if ext == "pdf":
        text, pages = _extract_pdf(uploaded_file)
        return text, "pdf", pages

    elif ext == "csv":
        df   = pd.read_csv(uploaded_file)
        text = df.to_string()
        return text, "csv", len(df)

    elif ext in ("xls", "xlsx"):
        df   = pd.read_excel(uploaded_file)
        text = df.to_string()
        return text, "xlsx", len(df)

    else:  # txt, md, etc.
        raw  = uploaded_file.read()
        text = raw.decode("utf-8", errors="ignore")
        return text, "txt", text.count("\n")


def _extract_pdf(uploaded_file) -> Tuple[str, int]:
    """Extract text from PDF using pdfplumber; falls back gracefully."""
    from config.settings import PDF_MAX_PAGES
    try:
        import pdfplumber
        data = uploaded_file.read()
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            total_pages = len(pdf.pages)
            pages_to_read = min(total_pages, PDF_MAX_PAGES)
            text = "\n".join(
                p.extract_text() or "" for p in pdf.pages[:pages_to_read]
            )
        return text, total_pages
    except ImportError:
        return "[pdfplumber not installed — run: pip install pdfplumber]", 0
    except Exception as e:
        return f"[PDF extraction error: {e}]", 0


# ── Text Analysis Utilities ───────────────────────────────────────

def top_words(text: str, n: int = 20) -> pd.DataFrame:
    """Return DataFrame of top n word frequencies from text."""
    STOP = {
        "the", "and", "for", "are", "that", "this", "with", "from",
        "have", "will", "been", "shall", "which", "their", "also",
        "they", "were", "such", "each", "than", "into", "when",
        "under", "over", "city", "area", "ward", "zone",
    }
    words = re.findall(r"\b[a-z]{4,}\b", text.lower())
    filtered = [w for w in words if w not in STOP]
    counts = Counter(filtered).most_common(n)
    return pd.DataFrame(counts, columns=["Word", "Count"])


# ── CSV / DataFrame Loaders ───────────────────────────────────────

def load_ward_csv(path: str) -> Optional[pd.DataFrame]:
    """Load a ward-level CSV and normalise column names."""
    try:
        df = pd.read_csv(path)
        # Normalise column names
        df.columns = [c.lower().strip().replace(" ", "_") for c in df.columns]
        return df
    except Exception:
        return None


def normalize_risk_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensure DataFrame has 'Ward' and 'Risk Score' columns.
    Tries common column aliases.
    """
    col_map = {}
    for col in df.columns:
        lc = col.lower()
        if "ward" in lc:
            col_map[col] = "Ward"
        elif any(k in lc for k in ["risk", "score", "ndvi", "green"]):
            col_map[col] = "Risk Score"

    df = df.rename(columns=col_map)

    if "Risk Score" in df.columns:
        df["Risk Score"] = pd.to_numeric(df["Risk Score"], errors="coerce").fillna(0.0)

    return df
